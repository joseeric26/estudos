import { ObjectId } from 'mongodb';

/**
 * Possíveis status de uma tarefa no sistema
 */
export type TaskStatus = 'pending' | 'in_progress' | 'completed';

/**
 * Estrutura do documento exatamente como é persistido na coleção do MongoDB
 */
export interface TaskDocument {
  _id?: ObjectId;
  title: string;
  description: string;
  status: TaskStatus;
  createdAt: Date;
  updatedAt: Date;
}

/**
 * Representação da Tarefa serializada em JSON para troca de dados com o frontend
 */
export interface ITask {
  _id: string;
  title: string;
  description: string;
  status: TaskStatus;
  createdAt: string;
  updatedAt: string;
}

/**
 * Payload de entrada para criação de uma nova tarefa
 */
export interface CreateTaskDTO {
  title: string;
  description: string;
  status?: TaskStatus;
}

/**
 * Payload de entrada para atualização de uma tarefa existente
 */
export interface UpdateTaskDTO {
  title?: string;
  description?: string;
  status?: TaskStatus;
}

/**
 * Rótulos humanizados em Português do Brasil para cada status
 */
export const STATUS_LABELS: Record<TaskStatus, string> = {
  pending: 'Pendente',
  in_progress: 'Em andamento',
  completed: 'Concluída',
};

/**
 * Configurações visuais (cores Tailwind) para os badges de status
 */
export const STATUS_STYLES: Record<
  TaskStatus,
  { bg: string; text: string; border: string; dot: string }
> = {
  pending: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    dot: 'bg-amber-500',
  },
  in_progress: {
    bg: 'bg-blue-50',
    text: 'text-blue-800',
    border: 'border-blue-200',
    dot: 'bg-blue-500',
  },
  completed: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-800',
    border: 'border-emerald-200',
    dot: 'bg-emerald-500',
  },
};
