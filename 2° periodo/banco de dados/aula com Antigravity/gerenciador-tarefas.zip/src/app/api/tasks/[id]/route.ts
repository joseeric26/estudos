import { NextResponse } from 'next/server';
import { ObjectId } from 'mongodb';
import { getDatabase } from '@/lib/mongodb';
import { TaskDocument, ITask, TaskStatus } from '@/types/task';

// Interface compatível com Next.js 14 e Next.js 15
interface RouteParams {
  params: {
    id: string;
  } | Promise<{
    id: string;
  }>;
}

/**
 * GET /api/tasks/[id]
 * Recupera uma única tarefa pelo seu identificador ObjectId do MongoDB.
 */
export async function GET(request: Request, context: RouteParams) {
  try {
    const { id } = await Promise.resolve(context.params);

    if (!id || !ObjectId.isValid(id)) {
      return NextResponse.json(
        { error: 'Identificador de tarefa inválido.' },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const task = await db
      .collection<TaskDocument>('tasks')
      .findOne({ _id: new ObjectId(id) });

    if (!task) {
      return NextResponse.json(
        { error: 'Tarefa não encontrada.' },
        { status: 404 }
      );
    }

    const formattedTask: ITask = {
      _id: task._id!.toString(),
      title: task.title,
      description: task.description,
      status: task.status,
      createdAt:
        task.createdAt instanceof Date
          ? task.createdAt.toISOString()
          : new Date(task.createdAt).toISOString(),
      updatedAt:
        task.updatedAt instanceof Date
          ? task.updatedAt.toISOString()
          : new Date(task.updatedAt).toISOString(),
    };

    return NextResponse.json(formattedTask, { status: 200 });
  } catch (error) {
    console.error('[API Tasks [id]] Erro ao consultar tarefa:', error);
    return NextResponse.json(
      { error: 'Erro interno ao consultar os dados da tarefa.' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/tasks/[id]
 * Atualiza campos de uma tarefa existente e registra a nova data de modificação.
 */
export async function PUT(request: Request, context: RouteParams) {
  try {
    const { id } = await Promise.resolve(context.params);

    if (!id || !ObjectId.isValid(id)) {
      return NextResponse.json(
        { error: 'Identificador de tarefa inválido.' },
        { status: 400 }
      );
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'Formato da requisição inválido. Envie um corpo JSON válido.' },
        { status: 400 }
      );
    }

    const { title, description, status } = body;

    const updateFields: Partial<TaskDocument> = {
      updatedAt: new Date(),
    };

    // Validações dos campos recebidos
    if (title !== undefined) {
      if (typeof title !== 'string' || title.trim().length === 0) {
        return NextResponse.json(
          { error: 'O título não pode ser vazio.' },
          { status: 400 }
        );
      }
      updateFields.title = title.trim();
    }

    if (description !== undefined) {
      if (typeof description !== 'string' || description.trim().length === 0) {
        return NextResponse.json(
          { error: 'A descrição não pode ser vazia.' },
          { status: 400 }
        );
      }
      updateFields.description = description.trim();
    }

    if (status !== undefined) {
      const allowedStatuses: TaskStatus[] = ['pending', 'in_progress', 'completed'];
      if (!allowedStatuses.includes(status)) {
        return NextResponse.json(
          { error: 'Status inválido. Escolha entre: pending, in_progress ou completed.' },
          { status: 400 }
        );
      }
      updateFields.status = status;
    }

    const db = await getDatabase();
    const result = await db.collection<TaskDocument>('tasks').findOneAndUpdate(
      { _id: new ObjectId(id) },
      { $set: updateFields },
      { returnDocument: 'after' }
    );

    if (!result) {
      return NextResponse.json(
        { error: 'Tarefa não encontrada para atualização.' },
        { status: 404 }
      );
    }

    const updatedTask: ITask = {
      _id: result._id!.toString(),
      title: result.title,
      description: result.description,
      status: result.status,
      createdAt:
        result.createdAt instanceof Date
          ? result.createdAt.toISOString()
          : new Date(result.createdAt).toISOString(),
      updatedAt:
        result.updatedAt instanceof Date
          ? result.updatedAt.toISOString()
          : new Date(result.updatedAt).toISOString(),
    };

    return NextResponse.json(updatedTask, { status: 200 });
  } catch (error) {
    console.error('[API Tasks [id]] Erro ao atualizar tarefa:', error);
    return NextResponse.json(
      { error: 'Erro interno ao atualizar a tarefa.' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/tasks/[id]
 * Remove permanentemente uma tarefa do banco de dados MongoDB.
 */
export async function DELETE(request: Request, context: RouteParams) {
  try {
    const { id } = await Promise.resolve(context.params);

    if (!id || !ObjectId.isValid(id)) {
      return NextResponse.json(
        { error: 'Identificador de tarefa inválido.' },
        { status: 400 }
      );
    }

    const db = await getDatabase();
    const result = await db
      .collection<TaskDocument>('tasks')
      .deleteOne({ _id: new ObjectId(id) });

    if (result.deletedCount === 0) {
      return NextResponse.json(
        { error: 'Tarefa não encontrada para exclusão.' },
        { status: 404 }
      );
    }

    return NextResponse.json(
      { message: 'Tarefa excluída com sucesso.' },
      { status: 200 }
    );
  } catch (error) {
    console.error('[API Tasks [id]] Erro ao excluir tarefa:', error);
    return NextResponse.json(
      { error: 'Erro interno ao excluir a tarefa.' },
      { status: 500 }
    );
  }
}
