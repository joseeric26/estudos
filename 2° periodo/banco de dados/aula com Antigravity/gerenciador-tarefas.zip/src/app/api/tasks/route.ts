import { NextResponse } from 'next/server';
import { getDatabase } from '@/lib/mongodb';
import { TaskDocument, ITask, TaskStatus } from '@/types/task';

/**
 * GET /api/tasks
 * Retorna a listagem de todas as tarefas cadastradas, ordenadas da mais recente para a mais antiga.
 */
export async function GET() {
  try {
    const db = await getDatabase();
    const rawTasks = await db
      .collection<TaskDocument>('tasks')
      .find({})
      .sort({ createdAt: -1 })
      .toArray();

    // Mapeia os documentos do MongoDB para o tipo ITask (com _id e datas em formato string ISO)
    const tasks: ITask[] = rawTasks.map((t) => ({
      _id: t._id!.toString(),
      title: t.title,
      description: t.description,
      status: t.status,
      createdAt:
        t.createdAt instanceof Date
          ? t.createdAt.toISOString()
          : new Date(t.createdAt).toISOString(),
      updatedAt:
        t.updatedAt instanceof Date
          ? t.updatedAt.toISOString()
          : new Date(t.updatedAt).toISOString(),
    }));

    return NextResponse.json(tasks, { status: 200 });
  } catch (error) {
    console.error('[API Tasks] Erro ao listar tarefas:', error);
    return NextResponse.json(
      { error: 'Não foi possível carregar as tarefas. Verifique a conexão com o banco de dados.' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/tasks
 * Valida e cadastra uma nova tarefa no banco de dados MongoDB.
 */
export async function POST(request: Request) {
  try {
    let body;
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'Formato da requisição inválido. Envie um corpo JSON válido.' },
        { status: 400 }
      );
    }

    const { title, description, status } = body;

    // 1. Validação do Título
    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      return NextResponse.json(
        { error: 'O título da tarefa é obrigatório e não pode conter apenas espaços.' },
        { status: 400 }
      );
    }

    // 2. Validação da Descrição
    if (!description || typeof description !== 'string' || description.trim().length === 0) {
      return NextResponse.json(
        { error: 'A descrição da tarefa é obrigatória e não pode conter apenas espaços.' },
        { status: 400 }
      );
    }

    // 3. Validação do Status
    const allowedStatuses: TaskStatus[] = ['pending', 'in_progress', 'completed'];
    const taskStatus: TaskStatus =
      status && allowedStatuses.includes(status) ? status : 'pending';

    const now = new Date();
    const newTask: TaskDocument = {
      title: title.trim(),
      description: description.trim(),
      status: taskStatus,
      createdAt: now,
      updatedAt: now,
    };

    const db = await getDatabase();
    const result = await db.collection<TaskDocument>('tasks').insertOne(newTask);

    const createdTask: ITask = {
      _id: result.insertedId.toString(),
      title: newTask.title,
      description: newTask.description,
      status: newTask.status,
      createdAt: newTask.createdAt.toISOString(),
      updatedAt: newTask.updatedAt.toISOString(),
    };

    return NextResponse.json(createdTask, { status: 201 });
  } catch (error) {
    console.error('[API Tasks] Erro ao cadastrar tarefa:', error);
    return NextResponse.json(
      { error: 'Erro interno no servidor ao tentar salvar a tarefa.' },
      { status: 500 }
    );
  }
}
