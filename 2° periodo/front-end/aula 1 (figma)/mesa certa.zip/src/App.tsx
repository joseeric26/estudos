import { useState } from "react";

type Screen = "home" | "filters" | "results";

type Filters = {
  ambiente: string[];
  preco: string[];
  gastronomia: string[];
  distancia: string;
  avaliacao: string;
  restricoes: string[];
  diferenciais: string[];
  reserva: string;
  aberto: boolean;
};

const EMPTY_FILTERS: Filters = {
  ambiente: [],
  preco: [],
  gastronomia: [],
  distancia: "",
  avaliacao: "",
  restricoes: [],
  diferenciais: [],
  reserva: "",
  aberto: false,
};

const RESTAURANTS = [
  {
    id: 1,
    name: "Sakura Izakaya",
    gastronomia: "Japonesa",
    ambiente: ["Reservado", "Íntimo"],
    preco: "$$",
    rating: 4.8,
    distanciaKm: 1.2,
    endereco: "Rua das Flores, 142 — Vila Madalena",
    descricao: "Ambiente íntimo com iluminação suave, sake artesanal e sushis autorais.",
    img: "https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=600&h=400&fit=crop&auto=format",
    tags: ["Sushi", "Sake", "Íntimo"],
    restricoes: ["Sem glúten disponível"],
    diferenciais: ["Wi-Fi", "Reserva online", "Ar-condicionado"],
    reserva: "Online",
    aberto: true,
  },
  {
    id: 2,
    name: "Trattoria della Nonna",
    gastronomia: "Italiana",
    ambiente: ["Familiar", "Animado"],
    preco: "$$",
    rating: 4.6,
    distanciaKm: 0.8,
    endereco: "Av. Paulista, 800 — Bela Vista",
    descricao: "Receitas transmitidas por gerações, massas frescas e vinhos da casa.",
    img: "https://images.unsplash.com/photo-1573821201069-dbf297ca410a?w=600&h=400&fit=crop&auto=format",
    tags: ["Pasta", "Vinho", "Familiar"],
    restricoes: ["Vegetariano", "Sem glúten disponível"],
    diferenciais: ["Estacionamento", "Ar-condicionado", "Acessível"],
    reserva: "Telefone",
    aberto: true,
  },
  {
    id: 3,
    name: "Fogo & Brasa",
    gastronomia: "Churrasco",
    ambiente: ["Com música ao vivo", "Animado"],
    preco: "$$$",
    rating: 4.9,
    distanciaKm: 2.1,
    endereco: "Rua Augusta, 500 — Consolação",
    descricao: "Churrasco na brasa, pagode ao vivo às sextas e caipirinhas artesanais.",
    img: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=600&h=400&fit=crop&auto=format",
    tags: ["Churrasco", "Música ao vivo", "Caipirinhas"],
    restricoes: [],
    diferenciais: ["Estacionamento", "Espaço para grupos", "Reserva necessária"],
    reserva: "Online",
    aberto: true,
  },
  {
    id: 4,
    name: "Le Petite Brasserie",
    gastronomia: "Francesa",
    ambiente: ["Calmo", "Romântico"],
    preco: "$$$",
    rating: 4.7,
    distanciaKm: 3.4,
    endereco: "Rua Oscar Freire, 210 — Jardins",
    descricao: "Bistrô parisiense com menu dégustation, vinhos naturais e ambiente sereno.",
    img: "https://images.unsplash.com/photo-1537047902294-62a40c20a6ae?w=600&h=400&fit=crop&auto=format",
    tags: ["Bistrô", "Vinho natural", "Sereno"],
    restricoes: ["Vegetariano", "Sem lactose disponível"],
    diferenciais: ["Wi-Fi", "Ar-condicionado", "Vista panorâmica"],
    reserva: "Online",
    aberto: false,
  },
  {
    id: 5,
    name: "Nikkei 21",
    gastronomia: "Nikkei",
    ambiente: ["Moderno", "Íntimo"],
    preco: "$$$",
    rating: 4.5,
    distanciaKm: 1.9,
    endereco: "Rua Haddock Lobo, 33 — Cerqueira César",
    descricao: "Fusão peruano-japonesa em ambiente contemporâneo com bar de ceviches.",
    img: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=600&h=400&fit=crop&auto=format",
    tags: ["Ceviche", "Fusão", "Contemporâneo"],
    restricoes: ["Sem glúten disponível"],
    diferenciais: ["Wi-Fi", "Delivery", "Reserva online"],
    reserva: "Online",
    aberto: true,
  },
  {
    id: 6,
    name: "Cantina do Porto",
    gastronomia: "Portuguesa",
    ambiente: ["Familiar", "Rústico"],
    preco: "$",
    rating: 4.4,
    distanciaKm: 0.5,
    endereco: "Rua do Comércio, 77 — Sé",
    descricao: "Bacalhau de sete maneiras, vinho verde e pastel de nata fresquinho.",
    img: "https://images.unsplash.com/photo-1652195960911-c9f55224bd89?w=600&h=400&fit=crop&auto=format",
    tags: ["Bacalhau", "Petiscos", "Tradicional"],
    restricoes: [],
    diferenciais: ["Estacionamento", "Takeout", "Acessível"],
    reserva: "Sem reserva",
    aberto: true,
  },
  {
    id: 7,
    name: "Roots & Green",
    gastronomia: "Vegana",
    ambiente: ["Calmo", "Moderno"],
    preco: "$$",
    rating: 4.6,
    distanciaKm: 1.0,
    endereco: "Rua Harmonia, 95 — Vila Madalena",
    descricao: "Cozinha vegana criativa com ingredientes orgânicos locais e sucos prensados a frio.",
    img: "https://images.unsplash.com/photo-1709548145082-04d0cde481d4?w=600&h=400&fit=crop&auto=format",
    tags: ["Vegano", "Orgânico", "Saudável"],
    restricoes: ["Vegano", "Vegetariano", "Sem glúten disponível", "Sem lactose disponível"],
    diferenciais: ["Wi-Fi", "Delivery", "Takeout", "Ar-condicionado"],
    reserva: "Online",
    aberto: true,
  },
  {
    id: 8,
    name: "Spice Garden",
    gastronomia: "Indiana",
    ambiente: ["Animado", "Familiar"],
    preco: "$$",
    rating: 4.3,
    distanciaKm: 2.8,
    endereco: "Av. Rebouças, 3300 — Pinheiros",
    descricao: "Curries aromáticos, naans artesanais e chá masala em ambiente vibrante.",
    img: "https://images.unsplash.com/photo-1602232037779-30b01ac3c457?w=600&h=400&fit=crop&auto=format",
    tags: ["Curry", "Naan", "Especiarias"],
    restricoes: ["Vegetariano", "Vegano", "Halal", "Sem lactose disponível"],
    diferenciais: ["Delivery", "Takeout", "Ar-condicionado"],
    reserva: "Sem reserva",
    aberto: true,
  },
  {
    id: 9,
    name: "Terraza Rooftop",
    gastronomia: "Contemporânea",
    ambiente: ["Rooftop", "Romântico", "Com música ao vivo"],
    preco: "$$$",
    rating: 4.7,
    distanciaKm: 0.9,
    endereco: "Rua Consolação, 1200 — 12º andar — Consolação",
    descricao: "Gastronomia contemporânea com vista da cidade, coquetéis autorais e DJ aos fins de semana.",
    img: "https://images.unsplash.com/photo-1570560258879-af7f8e1447ac?w=600&h=400&fit=crop&auto=format",
    tags: ["Rooftop", "Coquetéis", "Vista"],
    restricoes: ["Vegetariano"],
    diferenciais: ["Vista panorâmica", "Wi-Fi", "Reserva necessária", "Espaço para grupos"],
    reserva: "Online",
    aberto: false,
  },
  {
    id: 10,
    name: "Parrilla Don Carlos",
    gastronomia: "Argentina",
    ambiente: ["Rústico", "Animado"],
    preco: "$$$",
    rating: 4.8,
    distanciaKm: 4.2,
    endereco: "Rua Sergipe, 700 — Higienópolis",
    descricao: "Parrilla argentina com cortes nobres, empanadas e malbec importado.",
    img: "https://images.unsplash.com/photo-1583354608715-177553a4035e?w=600&h=400&fit=crop&auto=format",
    tags: ["Parrilla", "Cortes nobres", "Malbec"],
    restricoes: [],
    diferenciais: ["Estacionamento", "Ar-condicionado", "Espaço para grupos"],
    reserva: "Telefone",
    aberto: true,
  },
];

const FILTER_SECTIONS = [
  {
    key: "ambiente" as const,
    label: "Ambiente",
    sub: "Qual é o clima que você procura?",
    multi: true,
    options: [
      { val: "Calmo", icon: "🍃" },
      { val: "Reservado", icon: "🕯️" },
      { val: "Íntimo", icon: "💑" },
      { val: "Romântico", icon: "🌹" },
      { val: "Familiar", icon: "👨‍👩‍👧" },
      { val: "Animado", icon: "🎉" },
      { val: "Com música ao vivo", icon: "🎵" },
      { val: "Moderno", icon: "✨" },
      { val: "Rústico", icon: "🪵" },
      { val: "Industrial", icon: "🏗️" },
      { val: "Rooftop", icon: "🌆" },
      { val: "Ao ar livre", icon: "🌿" },
      { val: "Pet-friendly", icon: "🐾" },
      { val: "Para grupos", icon: "👥" },
      { val: "Esportivo", icon: "⚽" },
    ],
  },
  {
    key: "preco" as const,
    label: "Faixa de Preço",
    sub: "Quanto pretende gastar por pessoa?",
    multi: true,
    options: [
      { val: "$", icon: "💚", desc: "Até R$ 40" },
      { val: "$$", icon: "💛", desc: "R$ 40–80" },
      { val: "$$$", icon: "🧡", desc: "R$ 80–150" },
      { val: "$$$$", icon: "❤️", desc: "Acima de R$ 150" },
    ],
  },
  {
    key: "gastronomia" as const,
    label: "Tipo de Gastronomia",
    sub: "Qual culinária você está com vontade?",
    multi: true,
    options: [
      { val: "Brasileira", icon: "🇧🇷" },
      { val: "Italiana", icon: "🍕" },
      { val: "Japonesa", icon: "🍣" },
      { val: "Francesa", icon: "🥐" },
      { val: "Portuguesa", icon: "🐟" },
      { val: "Argentina", icon: "🥩" },
      { val: "Mexicana", icon: "🌮" },
      { val: "Indiana", icon: "🍛" },
      { val: "Tailandesa", icon: "🍜" },
      { val: "Chinesa", icon: "🥡" },
      { val: "Coreana", icon: "🥘" },
      { val: "Grega", icon: "🫒" },
      { val: "Espanhola", icon: "🥘" },
      { val: "Americana", icon: "🍔" },
      { val: "Peruana", icon: "🐟" },
      { val: "Árabe", icon: "🧆" },
      { val: "Nikkei", icon: "🔀" },
      { val: "Contemporânea", icon: "⭐" },
      { val: "Churrasco", icon: "🔥" },
      { val: "Frutos do mar", icon: "🦞" },
      { val: "Vegana", icon: "🌱" },
      { val: "Vegetariana", icon: "🥗" },
      { val: "Saudável", icon: "🥑" },
    ],
  },
  {
    key: "distancia" as const,
    label: "Distância máxima",
    sub: "Qual o raio de busca desejado?",
    multi: false,
    options: [
      { val: "0.5", icon: "🚶", desc: "Até 500 m" },
      { val: "1", icon: "🚶", desc: "Até 1 km" },
      { val: "2", icon: "🚲", desc: "Até 2 km" },
      { val: "5", icon: "🚗", desc: "Até 5 km" },
      { val: "10", icon: "🚗", desc: "Até 10 km" },
    ],
  },
  {
    key: "avaliacao" as const,
    label: "Avaliação mínima",
    sub: "Qual nota mínima você aceita?",
    multi: false,
    options: [
      { val: "3", icon: "⭐", desc: "3.0 ou mais" },
      { val: "4", icon: "⭐⭐", desc: "4.0 ou mais" },
      { val: "4.5", icon: "⭐⭐⭐", desc: "4.5 ou mais" },
    ],
  },
  {
    key: "restricoes" as const,
    label: "Restrições alimentares",
    sub: "Dietas e restrições que devem ser atendidas",
    multi: true,
    options: [
      { val: "Vegetariano", icon: "🥗" },
      { val: "Vegano", icon: "🌱" },
      { val: "Sem glúten disponível", icon: "🌾" },
      { val: "Sem lactose disponível", icon: "🥛" },
      { val: "Halal", icon: "☪️" },
      { val: "Kosher", icon: "✡️" },
    ],
  },
  {
    key: "diferenciais" as const,
    label: "Diferenciais",
    sub: "O que mais importa na sua experiência?",
    multi: true,
    options: [
      { val: "Estacionamento", icon: "🅿️" },
      { val: "Delivery", icon: "🛵" },
      { val: "Takeout", icon: "📦" },
      { val: "Wi-Fi", icon: "📶" },
      { val: "Ar-condicionado", icon: "❄️" },
      { val: "Acessível", icon: "♿" },
      { val: "Vista panorâmica", icon: "🌆" },
      { val: "Espaço para grupos", icon: "🎊" },
      { val: "Reserva necessária", icon: "📋" },
    ],
  },
  {
    key: "reserva" as const,
    label: "Tipo de reserva",
    sub: "Como prefere garantir sua mesa?",
    multi: false,
    options: [
      { val: "Online", icon: "💻", desc: "Reserva pelo app" },
      { val: "Telefone", icon: "📞", desc: "Reserva por ligação" },
      { val: "Sem reserva", icon: "🚪", desc: "Sem reserva necessária" },
    ],
  },
];

function countActiveFilters(f: Filters): number {
  return (
    f.ambiente.length +
    f.preco.length +
    f.gastronomia.length +
    (f.distancia ? 1 : 0) +
    (f.avaliacao ? 1 : 0) +
    f.restricoes.length +
    f.diferenciais.length +
    (f.reserva ? 1 : 0) +
    (f.aberto ? 1 : 0)
  );
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <svg key={s} viewBox="0 0 12 12" className={`w-3 h-3 ${s <= Math.round(rating) ? "fill-amber-400" : "fill-[#2e2822]"}`}>
          <path d="M6 0.5l1.545 3.13 3.455.502-2.5 2.437.59 3.441L6 8.25 2.91 9.91l.59-3.441L1 4.132l3.455-.502z" />
        </svg>
      ))}
      <span className="text-xs text-[#8a7d6e] ml-1">{rating}</span>
    </div>
  );
}

function PriceBadge({ preco }: { preco: string }) {
  const colors: Record<string, string> = {
    "$": "text-emerald-400 bg-emerald-400/10",
    "$$": "text-amber-400 bg-amber-400/10",
    "$$$": "text-orange-400 bg-orange-400/10",
    "$$$$": "text-rose-400 bg-rose-400/10",
  };
  return (
    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${colors[preco] ?? ""}`}>
      {preco}
    </span>
  );
}

function ToggleChip({
  label,
  icon,
  active,
  onClick,
}: {
  label: string;
  icon?: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 px-3 py-2 rounded-full border text-sm transition-all select-none ${
        active
          ? "bg-[#e8622a] border-[#e8622a] text-white"
          : "bg-[#1c1915] border-[#2e2822] text-[#d4c4b0] hover:border-[#e8622a]/60"
      }`}
    >
      {icon && <span className="text-base leading-none">{icon}</span>}
      {label}
    </button>
  );
}

function HomeScreen({ onSearch }: { onSearch: (location: string, query: string) => void }) {
  const [location, setLocation] = useState("");
  const [query, setQuery] = useState("");

  return (
    <div className="min-h-screen flex flex-col">
      <div className="relative flex-1 flex flex-col items-center justify-center px-6 py-20 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: "url(https://images.unsplash.com/photo-1590846406792-0adc7f938f1d?w=1400&h=900&fit=crop&auto=format)" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f0d0b]/60 via-[#0f0d0b]/40 to-[#0f0d0b]" />

        <div className="relative z-10 max-w-xl w-full text-center space-y-8">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-[#e8622a] mb-4">
              <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
                <path d="M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm5-3v8h2.5v8H21V2c-2.76 0-5 2.24-5 4z" />
              </svg>
              <span className="font-['Fraunces'] text-2xl font-semibold tracking-wide">Mesa Certa</span>
            </div>
            <h1 className="font-['Fraunces'] text-5xl md:text-6xl font-bold leading-tight text-[#f5efe6]">
              Encontre seu<br />
              <em className="text-[#e8622a] not-italic">restaurante perfeito</em>
            </h1>
            <p className="text-[#8a7d6e] text-lg mt-3">
              Filtre por ambiente, gastronomia, preço e muito mais.
            </p>
          </div>

          <div className="space-y-3 text-left">
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#8a7d6e]">
                <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                </svg>
              </span>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Digite a localização desejada..."
                className="w-full bg-[#1c1915] border border-[#2e2822] rounded-xl pl-12 pr-4 py-4 text-[#f5efe6] placeholder-[#8a7d6e] focus:outline-none focus:border-[#e8622a] transition-colors"
              />
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#8a7d6e]">
                <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                  <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
                </svg>
              </span>
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && onSearch(location, query)}
                placeholder="Buscar por nome ou culinária..."
                className="w-full bg-[#1c1915] border border-[#2e2822] rounded-xl pl-12 pr-4 py-4 text-[#f5efe6] placeholder-[#8a7d6e] focus:outline-none focus:border-[#e8622a] transition-colors"
              />
            </div>
            <button
              onClick={() => onSearch(location, query)}
              className="w-full bg-[#e8622a] hover:bg-[#d4561f] text-white font-semibold py-4 rounded-xl transition-colors text-lg"
            >
              Buscar Restaurantes
            </button>
          </div>
        </div>
      </div>

      <div className="relative z-10 px-6 pb-10">
        <p className="text-[#8a7d6e] text-sm font-medium mb-4 text-center">Explorar por gastronomia</p>
        <div className="flex flex-wrap justify-center gap-2">
          {["🍣 Japonesa", "🍕 Italiana", "🥩 Churrasco", "🥐 Francesa", "🌮 Mexicana", "🐟 Portuguesa", "🌱 Vegana", "🍔 Americana"].map((cat) => (
            <button
              key={cat}
              onClick={() => onSearch(location, cat.split(" ")[1])}
              className="px-4 py-2 bg-[#1c1915] border border-[#2e2822] rounded-full text-sm text-[#d4c4b0] hover:border-[#e8622a] hover:text-[#e8622a] transition-colors"
            >
              {cat}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function FiltersScreen({ onApply, onBack, initial }: { onApply: (f: Filters) => void; onBack: () => void; initial: Filters }) {
  const [filters, setFilters] = useState<Filters>(initial);

  const toggleMulti = (key: "ambiente" | "gastronomia" | "restricoes" | "diferenciais" | "preco", val: string) => {
    setFilters((f) => {
      const arr = f[key] as string[];
      return { ...f, [key]: arr.includes(val) ? arr.filter((x) => x !== val) : [...arr, val] };
    });
  };

  const setSingle = (key: "distancia" | "avaliacao" | "reserva", val: string) => {
    setFilters((f) => ({ ...f, [key]: f[key] === val ? "" : val }));
  };

  const activeCount = countActiveFilters(filters);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="relative h-48 overflow-hidden flex-shrink-0">
        <img
          src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1200&h=400&fit=crop&auto=format"
          alt="Restaurante"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#0f0d0b]/40 to-[#0f0d0b]" />
        <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between">
          <div>
            <p className="text-[#8a7d6e] text-sm">Personalize sua busca</p>
            <h2 className="font-['Fraunces'] text-3xl font-bold text-[#f5efe6]">Filtros</h2>
          </div>
          <div className="flex items-center gap-3">
            {activeCount > 0 && (
              <button
                onClick={() => setFilters(EMPTY_FILTERS)}
                className="text-xs text-[#8a7d6e] hover:text-[#e8622a] transition-colors underline"
              >
                Limpar tudo
              </button>
            )}
            <button
              onClick={onBack}
              className="flex items-center gap-1.5 text-[#8a7d6e] hover:text-[#f5efe6] transition-colors text-sm"
            >
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
              </svg>
              Voltar
            </button>
          </div>
        </div>
      </div>

      {/* Scrollable filters body */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-6 py-6 space-y-8 pb-32">

          {/* Aberto agora toggle */}
          <div className="flex items-center justify-between p-4 bg-[#1c1915] border border-[#2e2822] rounded-xl">
            <div>
              <p className="text-[#d4c4b0] font-semibold">Aberto agora</p>
              <p className="text-[#8a7d6e] text-sm">Mostrar apenas restaurantes abertos</p>
            </div>
            <button
              onClick={() => setFilters((f) => ({ ...f, aberto: !f.aberto }))}
              className={`relative w-12 h-6 rounded-full transition-colors ${filters.aberto ? "bg-[#e8622a]" : "bg-[#2e2822]"}`}
            >
              <span
                className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${filters.aberto ? "translate-x-6" : "translate-x-0.5"}`}
              />
            </button>
          </div>

          {FILTER_SECTIONS.map((section) => (
            <div key={section.key}>
              <h3 className="text-[#d4c4b0] font-semibold text-base mb-0.5">{section.label}</h3>
              <p className="text-[#8a7d6e] text-sm mb-3">{section.sub}</p>

              {section.key === "preco" ? (
                <div className="grid grid-cols-4 gap-2">
                  {section.options.map((opt) => {
                    const active = (filters.preco as string[]).includes(opt.val);
                    return (
                      <button
                        key={opt.val}
                        onClick={() => toggleMulti("preco", opt.val)}
                        className={`py-3 rounded-xl border text-center transition-all ${
                          active
                            ? "bg-[#e8622a]/15 border-[#e8622a] text-[#e8622a]"
                            : "bg-[#1c1915] border-[#2e2822] text-[#d4c4b0] hover:border-[#e8622a]/60"
                        }`}
                      >
                        <div className="text-lg font-bold">{opt.val}</div>
                        {"desc" in opt && <div className="text-xs text-[#8a7d6e] mt-0.5">{opt.desc}</div>}
                      </button>
                    );
                  })}
                </div>
              ) : section.key === "distancia" || section.key === "avaliacao" || section.key === "reserva" ? (
                <div className="flex flex-wrap gap-2">
                  {section.options.map((opt) => {
                    const active = filters[section.key as "distancia" | "avaliacao" | "reserva"] === opt.val;
                    return (
                      <button
                        key={opt.val}
                        onClick={() => setSingle(section.key as "distancia" | "avaliacao" | "reserva", opt.val)}
                        className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm transition-all ${
                          active
                            ? "bg-[#e8622a]/15 border-[#e8622a] text-[#e8622a]"
                            : "bg-[#1c1915] border-[#2e2822] text-[#d4c4b0] hover:border-[#e8622a]/60"
                        }`}
                      >
                        <span>{opt.icon}</span>
                        <span>{"desc" in opt ? opt.desc : opt.val}</span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {section.options.map((opt) => {
                    const arr = filters[section.key as "ambiente" | "gastronomia" | "restricoes" | "diferenciais"] as string[];
                    const active = arr.includes(opt.val);
                    return (
                      <ToggleChip
                        key={opt.val}
                        label={opt.val}
                        icon={opt.icon}
                        active={active}
                        onClick={() => toggleMulti(section.key as "ambiente" | "gastronomia" | "restricoes" | "diferenciais", opt.val)}
                      />
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Sticky footer */}
      <div className="sticky bottom-0 bg-[#0f0d0b]/95 backdrop-blur border-t border-[#2e2822] px-6 py-4">
        <button
          onClick={() => onApply(filters)}
          className="w-full max-w-2xl mx-auto flex items-center justify-center gap-3 bg-[#e8622a] hover:bg-[#d4561f] text-white font-semibold py-4 rounded-xl transition-colors text-lg"
        >
          Ver Restaurantes
          {activeCount > 0 && (
            <span className="bg-white/20 text-white text-sm px-2.5 py-0.5 rounded-full">
              {activeCount} filtro{activeCount !== 1 ? "s" : ""}
            </span>
          )}
        </button>
      </div>
    </div>
  );
}

function ResultsScreen({
  filters,
  location,
  query,
  onBack,
  onFilters,
}: {
  filters: Filters;
  location: string;
  query: string;
  onBack: () => void;
  onFilters: () => void;
}) {
  const [selected, setSelected] = useState<number | null>(null);

  const filtered = RESTAURANTS.filter((r) => {
    if (filters.ambiente.length && !filters.ambiente.some((a) => r.ambiente.includes(a))) return false;
    if (filters.preco.length && !filters.preco.includes(r.preco)) return false;
    if (filters.gastronomia.length && !filters.gastronomia.includes(r.gastronomia)) return false;
    if (filters.distancia && r.distanciaKm > parseFloat(filters.distancia)) return false;
    if (filters.avaliacao && r.rating < parseFloat(filters.avaliacao)) return false;
    if (filters.restricoes.length && !filters.restricoes.every((res) => r.restricoes.includes(res))) return false;
    if (filters.diferenciais.length && !filters.diferenciais.every((d) => r.diferenciais.includes(d))) return false;
    if (filters.reserva && r.reserva !== filters.reserva) return false;
    if (filters.aberto && !r.aberto) return false;
    if (query && !r.name.toLowerCase().includes(query.toLowerCase()) && !r.gastronomia.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  }).sort((a, b) => b.rating - a.rating);

  const activeCount = countActiveFilters(filters);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-20 bg-[#0f0d0b]/90 backdrop-blur-md border-b border-[#2e2822] px-6 py-4">
        <div className="max-w-3xl mx-auto flex items-center gap-4">
          <button onClick={onBack} className="text-[#8a7d6e] hover:text-[#f5efe6] transition-colors">
            <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
              <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z" />
            </svg>
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-['Fraunces'] text-lg font-semibold text-[#f5efe6]">
                {filtered.length} restaurante{filtered.length !== 1 ? "s" : ""}
              </span>
              {location && <span className="text-[#8a7d6e] text-sm truncate">— {location}</span>}
            </div>
            {activeCount > 0 && (
              <p className="text-[#8a7d6e] text-xs mt-0.5">{activeCount} filtro{activeCount !== 1 ? "s" : ""} ativo{activeCount !== 1 ? "s" : ""}</p>
            )}
          </div>
          <button
            onClick={onFilters}
            className="relative flex items-center gap-2 px-3 py-2 border border-[#2e2822] hover:border-[#e8622a] rounded-lg text-sm text-[#d4c4b0] hover:text-[#e8622a] transition-colors flex-shrink-0"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current">
              <path d="M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z" />
            </svg>
            Filtros
            {activeCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#e8622a] text-white text-xs rounded-full flex items-center justify-center font-bold">
                {activeCount}
              </span>
            )}
          </button>
        </div>
      </header>

      <main className="flex-1 px-6 py-6 max-w-3xl mx-auto w-full">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="text-5xl mb-4">🍽️</div>
            <h3 className="font-['Fraunces'] text-2xl font-semibold text-[#f5efe6] mb-2">Nenhum resultado</h3>
            <p className="text-[#8a7d6e] mb-6">Tente ajustar os filtros para ver mais opções.</p>
            <button
              onClick={onFilters}
              className="px-6 py-3 bg-[#e8622a] hover:bg-[#d4561f] text-white rounded-xl transition-colors"
            >
              Ajustar filtros
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((r, i) => (
              <div
                key={r.id}
                onClick={() => setSelected(selected === r.id ? null : r.id)}
                className="group cursor-pointer bg-[#1c1915] border border-[#2e2822] hover:border-[#e8622a]/50 rounded-2xl overflow-hidden transition-all"
              >
                <div className="flex gap-4 p-4">
                  <div className="flex-shrink-0 w-7 flex items-start pt-1">
                    <span className={`text-sm font-bold ${i === 0 ? "text-amber-400" : "text-[#8a7d6e]"}`}>#{i + 1}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="font-['Fraunces'] text-lg font-semibold text-[#f5efe6] group-hover:text-[#e8622a] transition-colors leading-tight">
                          {r.name}
                        </h3>
                        <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                          <span className="text-xs text-[#8a7d6e]">{r.gastronomia}</span>
                          <span className="text-[#2e2822]">·</span>
                          <span className="text-xs text-[#8a7d6e]">{r.ambiente[0]}</span>
                          {r.aberto ? (
                            <span className="text-xs text-emerald-400">● Aberto</span>
                          ) : (
                            <span className="text-xs text-[#8a7d6e]">● Fechado</span>
                          )}
                        </div>
                      </div>
                      <PriceBadge preco={r.preco} />
                    </div>
                    <div className="flex items-center gap-3 mt-2">
                      <StarRating rating={r.rating} />
                      <span className="text-xs text-[#8a7d6e] flex items-center gap-1">
                        <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
                          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" />
                        </svg>
                        {r.distanciaKm.toFixed(1)} km
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {r.tags.map((t) => (
                        <span key={t} className="text-xs text-[#8a7d6e] bg-[#2a2520] px-2 py-0.5 rounded-full">{t}</span>
                      ))}
                    </div>
                  </div>
                  <div className="flex-shrink-0 w-24 h-24 md:w-28 md:h-28 rounded-xl overflow-hidden bg-[#2a2520]">
                    <img
                      src={r.img}
                      alt={r.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                </div>

                {selected === r.id && (
                  <div className="px-4 pb-4 pl-[3.25rem] border-t border-[#2e2822] pt-3 space-y-3">
                    <p className="text-[#8a7d6e] text-sm leading-relaxed">{r.descricao}</p>
                    <div className="flex items-center gap-1 text-xs text-[#8a7d6e]">
                      <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current flex-shrink-0">
                        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                      </svg>
                      {r.endereco}
                    </div>
                    {r.diferenciais.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {r.diferenciais.map((d) => (
                          <span key={d} className="text-xs text-[#e8622a] bg-[#e8622a]/10 px-2 py-0.5 rounded-full">{d}</span>
                        ))}
                      </div>
                    )}
                    {r.restricoes.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {r.restricoes.map((res) => (
                          <span key={res} className="text-xs text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-full">{res}</span>
                        ))}
                      </div>
                    )}
                    <button className="w-full py-2.5 bg-[#e8622a] hover:bg-[#d4561f] text-white text-sm font-semibold rounded-lg transition-colors">
                      Ver no mapa
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [filters, setFilters] = useState<Filters>(EMPTY_FILTERS);
  const [location, setLocation] = useState("");
  const [query, setQuery] = useState("");

  const handleSearch = (loc: string, q: string) => {
    setLocation(loc);
    setQuery(q);
    setScreen("filters");
  };

  const handleApplyFilters = (f: Filters) => {
    setFilters(f);
    setScreen("results");
  };

  return (
    <div className="min-h-screen bg-[#0f0d0b] text-[#f5efe6]">
      {screen === "home" && <HomeScreen onSearch={handleSearch} />}
      {screen === "filters" && (
        <FiltersScreen
          initial={filters}
          onApply={handleApplyFilters}
          onBack={() => setScreen("home")}
        />
      )}
      {screen === "results" && (
        <ResultsScreen
          filters={filters}
          location={location}
          query={query}
          onBack={() => setScreen("home")}
          onFilters={() => setScreen("filters")}
        />
      )}
    </div>
  );
}
