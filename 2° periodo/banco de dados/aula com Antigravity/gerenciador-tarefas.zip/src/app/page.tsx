'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from '@/components/Navbar';
import { TaskCard } from '@/components/TaskCard';
import { TaskFormModal } from '@/components/TaskFormModal';
import { TaskDetailsModal } from '@/components/TaskDetailsModal';
import { DeleteConfirmModal } from '@/components/DeleteConfirmModal';
import { Toast, ToastMessage } from '@/components/Toast';
import { ITask, TaskStatus } from '@/types/task';

export default function HomePage() {
  const [tasks, setTasks] = useState<ITask[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'all' | TaskStatus>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Modais de ação
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<ITask | null>(null);
  const [viewingTask, setViewingTask] = useState<ITask | null>(null);
  const [deletingTask, setDeletingTask] = useState<ITask | null>(null);

  // Notificação Toast
  const [toast, setToast] = useState<ToastMessage | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
  };

  // Carregar lista de tarefas da API
  const fetchTasks = async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/tasks');
      if (!res.ok) {
        throw new Error('Falha ao buscar tarefas no servidor');
      }
      const data = await res.json();
      setTasks(data);
    } catch (err) {
      console.error(err);
      showToast(
        'Erro ao conectar com o banco de dados. Verifique os containers.',
        'error'
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  // Criar nova tarefa
  const handleCreate = async (formData: {
    title: string;
    description: string;
    status: TaskStatus;
  }) => {
    const res = await fetch('/api/tasks', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      showToast(errorData.error || 'Erro ao criar a tarefa.', 'error');
      throw new Error('Erro ao criar tarefa');
    }

    const newTask = await res.json();
    setTasks((prev) => [newTask, ...prev]);
    showToast('Tarefa criada com sucesso!', 'success');
  };

  // Atualizar tarefa existente
  const handleUpdate = async (formData: {
    title: string;
    description: string;
    status: TaskStatus;
  }) => {
    if (!editingTask) return;

    const res = await fetch(`/api/tasks/${editingTask._id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      showToast(errorData.error || 'Erro ao atualizar tarefa.', 'error');
      throw new Error('Erro ao atualizar tarefa');
    }

    const updated = await res.json();
    setTasks((prev) => prev.map((t) => (t._id === updated._id ? updated : t)));
    setEditingTask(null);
    showToast('Tarefa atualizada com sucesso!', 'success');
  };

  // Alteração rápida de status direto pelo card
  const handleQuickStatusChange = async (id: string, newStatus: TaskStatus) => {
    try {
      const res = await fetch(`/api/tasks/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!res.ok) {
        throw new Error('Falha ao mudar status');
      }

      const updated = await res.json();
      setTasks((prev) => prev.map((t) => (t._id === updated._id ? updated : t)));
      showToast('Status da tarefa atualizado!', 'info');
    } catch {
      showToast('Erro ao atualizar o status.', 'error');
    }
  };

  // Excluir tarefa
  const handleDelete = async (id: string) => {
    const res = await fetch(`/api/tasks/${id}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      showToast(errorData.error || 'Erro ao excluir a tarefa.', 'error');
      throw new Error('Erro ao excluir tarefa');
    }

    setTasks((prev) => prev.filter((t) => t._id !== id));
    setDeletingTask(null);
    showToast('Tarefa excluída com sucesso!', 'success');
  };

  // Estatísticas calculadas dinamicamente
  const stats = useMemo(() => {
    return {
      total: tasks.length,
      pending: tasks.filter((t) => t.status === 'pending').length,
      inProgress: tasks.filter((t) => t.status === 'in_progress').length,
      completed: tasks.filter((t) => t.status === 'completed').length,
    };
  }, [tasks]);

  // Lista filtrada por status e termo de pesquisa
  const filteredTasks = useMemo(() => {
    return tasks.filter((task) => {
      const matchesStatus =
        statusFilter === 'all' ? true : task.status === statusFilter;
      const matchesSearch =
        task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [tasks, statusFilter, searchTerm]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Painel de Boas-Vindas e Ação Principal */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Painel de Atividades
            </h2>
            <p className="text-sm sm:text-base text-slate-500 mt-1">
              Gerencie suas tarefas acadêmicas com persistência em MongoDB e conteinerização Docker.
            </p>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold text-sm shadow-lg shadow-indigo-100 hover:shadow-indigo-200 transition-all duration-150 cursor-pointer"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
            </svg>
            <span>Nova Tarefa</span>
          </button>
        </div>

        {/* Cards de Métricas e Contadores */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div
            onClick={() => setStatusFilter('all')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              statusFilter === 'all'
                ? 'bg-indigo-50/70 border-indigo-300 ring-2 ring-indigo-500/20 shadow-sm'
                : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
            }`}
          >
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total de Tarefas
            </div>
            <div className="text-2xl sm:text-3xl font-black text-slate-900 mt-1">
              {stats.total}
            </div>
          </div>

          <div
            onClick={() => setStatusFilter('pending')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              statusFilter === 'pending'
                ? 'bg-amber-50/70 border-amber-300 ring-2 ring-amber-500/20 shadow-sm'
                : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
            }`}
          >
            <div className="text-xs font-semibold text-amber-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              Pendentes
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-900 mt-1">
              {stats.pending}
            </div>
          </div>

          <div
            onClick={() => setStatusFilter('in_progress')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              statusFilter === 'in_progress'
                ? 'bg-blue-50/70 border-blue-300 ring-2 ring-blue-500/20 shadow-sm'
                : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
            }`}
          >
            <div className="text-xs font-semibold text-blue-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-500" />
              Em Andamento
            </div>
            <div className="text-2xl sm:text-3xl font-black text-blue-900 mt-1">
              {stats.inProgress}
            </div>
          </div>

          <div
            onClick={() => setStatusFilter('completed')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer ${
              statusFilter === 'completed'
                ? 'bg-emerald-50/70 border-emerald-300 ring-2 ring-emerald-500/20 shadow-sm'
                : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
            }`}
          >
            <div className="text-xs font-semibold text-emerald-700 uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              Concluídas
            </div>
            <div className="text-2xl sm:text-3xl font-black text-emerald-900 mt-1">
              {stats.completed}
            </div>
          </div>
        </div>

        {/* Barra de Filtros e Pesquisa */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm mb-6 flex flex-col sm:flex-row gap-4 justify-between items-center">
          {/* Campo de Busca */}
          <div className="relative w-full sm:w-80">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              placeholder="Buscar por título ou descrição..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
            />
          </div>

          {/* Abas de Filtro de Status */}
          <div className="flex items-center gap-1 bg-slate-100/80 p-1 rounded-xl w-full sm:w-auto overflow-x-auto">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                statusFilter === 'all'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Todas ({stats.total})
            </button>
            <button
              onClick={() => setStatusFilter('pending')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                statusFilter === 'pending'
                  ? 'bg-white text-amber-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Pendentes ({stats.pending})
            </button>
            <button
              onClick={() => setStatusFilter('in_progress')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                statusFilter === 'in_progress'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Em Andamento ({stats.inProgress})
            </button>
            <button
              onClick={() => setStatusFilter('completed')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all whitespace-nowrap ${
                statusFilter === 'completed'
                  ? 'bg-white text-emerald-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Concluídas ({stats.completed})
            </button>
          </div>
        </div>

        {/* Área Principal de Exibição das Tarefas */}
        {isLoading ? (
          /* Skeletons de Carregamento */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div
                key={i}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm animate-pulse space-y-4"
              >
                <div className="flex justify-between items-center">
                  <div className="w-24 h-6 bg-slate-200 rounded-full" />
                  <div className="w-16 h-6 bg-slate-200 rounded-lg" />
                </div>
                <div className="w-3/4 h-5 bg-slate-200 rounded" />
                <div className="space-y-2">
                  <div className="w-full h-3.5 bg-slate-100 rounded" />
                  <div className="w-5/6 h-3.5 bg-slate-100 rounded" />
                </div>
                <div className="pt-3 border-t border-slate-100 flex justify-between">
                  <div className="w-28 h-4 bg-slate-200 rounded" />
                  <div className="w-20 h-4 bg-slate-200 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : filteredTasks.length === 0 ? (
          /* Estado Vazio */
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center max-w-lg mx-auto shadow-sm my-8">
            <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-4 border border-indigo-100 shadow-sm">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>

            {tasks.length === 0 ? (
              <>
                <h3 className="text-xl font-bold text-slate-800 mb-2">
                  Nenhuma tarefa cadastrada
                </h3>
                <p className="text-sm text-slate-500 mb-6 leading-relaxed">
                  Seu banco de dados MongoDB está pronto e esperando! Comece cadastrando sua primeira atividade agora mesmo.
                </p>
                <button
                  onClick={() => setIsCreateModalOpen(true)}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-sm shadow-md shadow-indigo-100 transition-all cursor-pointer"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                  </svg>
                  <span>Cadastrar Primeira Tarefa</span>
                </button>
              </>
            ) : (
              <>
                <h3 className="text-lg font-bold text-slate-800 mb-2">
                  Nenhum resultado encontrado
                </h3>
                <p className="text-sm text-slate-500 mb-6">
                  Não foram encontradas tarefas com os filtros e termo de busca informados.
                </p>
                <button
                  onClick={() => {
                    setStatusFilter('all');
                    setSearchTerm('');
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-sm transition-colors"
                >
                  Limpar Filtros de Busca
                </button>
              </>
            )}
          </div>
        ) : (
          /* Grid de Cards */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredTasks.map((task) => (
              <TaskCard
                key={task._id}
                task={task}
                onView={(t) => setViewingTask(t)}
                onEdit={(t) => setEditingTask(t)}
                onDelete={(t) => setDeletingTask(t)}
                onStatusChange={handleQuickStatusChange}
              />
            ))}
          </div>
        )}
      </main>

      {/* Rodapé Acadêmico */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-400">
          <p>
            Projeto Prático de Engenharia da Computação &bull; Banco de Dados NoSQL &amp; Arquitetura em Containers
          </p>
          <p className="mt-1 font-mono text-slate-300">
            Next.js (App Router) + MongoDB Driver + Docker Compose
          </p>
        </div>
      </footer>

      {/* Modal de Criação */}
      <TaskFormModal
        isOpen={isCreateModalOpen}
        initialData={null}
        onClose={() => setIsCreateModalOpen(false)}
        onSubmit={handleCreate}
      />

      {/* Modal de Edição */}
      <TaskFormModal
        isOpen={!!editingTask}
        initialData={editingTask}
        onClose={() => setEditingTask(null)}
        onSubmit={handleUpdate}
      />

      {/* Modal de Visualização de Detalhes */}
      <TaskDetailsModal
        isOpen={!!viewingTask}
        task={viewingTask}
        onClose={() => setViewingTask(null)}
        onEdit={(taskToEdit) => {
          setViewingTask(null);
          setEditingTask(taskToEdit);
        }}
      />

      {/* Modal de Confirmação de Exclusão */}
      <DeleteConfirmModal
        isOpen={!!deletingTask}
        task={deletingTask}
        onClose={() => setDeletingTask(null)}
        onConfirm={handleDelete}
      />

      {/* Feedback Toast */}
      <Toast toast={toast} onClose={() => setToast(null)} />
    </div>
  );
}
